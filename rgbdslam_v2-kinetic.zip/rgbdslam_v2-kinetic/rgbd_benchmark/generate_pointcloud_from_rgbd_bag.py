#!/usr/bin/env python
import pyximport; pyximport.install()
import generate_pointcloud_from_rgbd_bag_module as add

add.main()


